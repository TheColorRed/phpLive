<?php
require_once "../../phpLive/phpLive.php";
echo $live->inet_aton("10.0.5.9");
echo "<br />";
print_r($live->inet_ntoa(167773449));
?>